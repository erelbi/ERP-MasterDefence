## Kurulum
1.
```bash
git clone https://github.com/huseyinerdall/ysib.git
cd ysib
```
2.
```bash
source venv/bin/activate
```
3.
```bash
pip3 install requirements.txt
```
4.
```bash
cd ysib
```
5.
```bash
python manage.py makemigrations
python manage.py migrate
python manage.py runserver
```
