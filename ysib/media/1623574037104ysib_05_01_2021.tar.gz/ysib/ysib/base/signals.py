from django.db.models.signals import post_save
from django.dispatch import receiver
from asgiref.sync import async_to_sync
from channels.layers import get_channel_layer
from base.models import Emir , User, Bildirim
from django.contrib.auth.models import User


@receiver(post_save, sender=Emir)
def announce_new_job(sender, instance, created, **kwargs):
    if created:
        channel_layer = get_channel_layer()
        async_to_sync(channel_layer.group_send)(
            "notifiy", {"type": "send.notifiy",
                       "event": "is emri",
                       "kisi": instance.emri_veren,
                       "emir": instance.is_emri,
                       "grupp": instance.grup})


#Üretim kontrol bitince
#Üretim kontrol başlayınca
#Öncelik sırası değişince
@receiver(post_save, sender=Bildirim)
def announce_starting(sender, instance, created, **kwargs):
    if created:
        channel_layer = get_channel_layer()
        async_to_sync(channel_layer.group_send)(
            "notifiy", {"type": "send.notifiy",
                       "event": instance.tur,
                       "grup" : instance.emri_veren_grup})
